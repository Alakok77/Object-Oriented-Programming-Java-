public class Main {
 public static void main(String[] args) {
//    new CalculatorOneGUI();
    new CalculatorTwoGUI();
//    new TellerGUI();
//    new MDIFromGUI();
 }
}